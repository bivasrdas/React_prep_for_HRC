const disp=function(){
const user=document.getElementById("name");
const pwd=document.getElementById("pass");
if(n.user.value.equals("1705141@kiit.ac.in"))
{
    if(pwd.pass.value.equals("12345678"))
    {
        alert("Login Successful");
    }
    else
    {
        alert("Incorrect Password");
    }
}
else
{
    alert("Incorrect User Name");
}
if(!emailid.includes("@"))
{
    alert("Enter Valid Email Id");
}
console.log(n);
}